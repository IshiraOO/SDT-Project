// Initialize map centered on Colombo
const map = L.map('map').setView([6.9271, 79.8612], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Initialize chart
let aqiChart = null;
const chartCtx = document.getElementById('aqiChart').getContext('2d');

// Function to get AQI color based on value
function getAQIColor(aqi) {
    if (aqi <= 50) return '#00e400';
    if (aqi <= 100) return '#ffff00';
    if (aqi <= 150) return '#ff7e00';
    if (aqi <= 200) return '#ff0000';
    return '#8f3f97';
}

// Function to create marker popup content
function createPopupContent(sensor) {
    return `
        <div class="popup-content">
            <h3>Sensor ${sensor.id}</h3>
            <p>Current AQI: ${sensor.aqi}</p>
            <p>Last Updated: ${new Date(sensor.last_updated).toLocaleString()}</p>
        </div>
    `;
}

// Function to update sensor markers on map
async function updateSensorMarkers() {
    try {
        const response = await fetch('api/get_sensors.php');
        const sensors = await response.json();
        
        // Clear existing markers
        map.eachLayer((layer) => {
            if (layer instanceof L.Marker) {
                map.removeLayer(layer);
            }
        });

        // Add new markers
        sensors.forEach(sensor => {
            const marker = L.marker([sensor.latitude, sensor.longitude])
                .bindPopup(createPopupContent(sensor))
                .addTo(map);

            // Set marker color based on AQI
            marker.getElement().style.backgroundColor = getAQIColor(sensor.aqi);
        });

        // Update sensor select dropdown
        updateSensorSelect(sensors);
    } catch (error) {
        console.error('Error updating sensor markers:', error);
    }
}

// Function to update sensor select dropdown
function updateSensorSelect(sensors) {
    const select = document.getElementById('sensorSelect');
    select.innerHTML = '<option value="">Select a Sensor</option>';
    
    sensors.forEach(sensor => {
        const option = document.createElement('option');
        option.value = sensor.id;
        option.textContent = `Sensor ${sensor.id}`;
        select.appendChild(option);
    });
}

// Function to update chart
async function updateChart(sensorId, timeRange) {
    try {
        const response = await fetch(`api/get_historical_data.php?sensor_id=${sensorId}&hours=${timeRange}`);
        const data = await response.json();

        if (aqiChart) {
            aqiChart.destroy();
        }

        aqiChart = new Chart(chartCtx, {
            type: 'line',
            data: {
                labels: data.map(d => new Date(d.timestamp).toLocaleString()),
                datasets: [{
                    label: 'AQI',
                    data: data.map(d => d.aqi),
                    borderColor: '#2c3e50',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'AQI Value'
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error updating chart:', error);
    }
}

// Event listeners
document.getElementById('sensorSelect').addEventListener('change', (e) => {
    const sensorId = e.target.value;
    const timeRange = document.getElementById('timeRange').value;
    if (sensorId) {
        updateChart(sensorId, timeRange);
    }
});

document.getElementById('timeRange').addEventListener('change', (e) => {
    const sensorId = document.getElementById('sensorSelect').value;
    if (sensorId) {
        updateChart(sensorId, e.target.value);
    }
});

// Initial updates
updateSensorMarkers();

// Update data every 5 minutes
setInterval(updateSensorMarkers, 300000); 