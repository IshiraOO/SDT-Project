-- Create database
CREATE DATABASE IF NOT EXISTS colombo_air;
USE colombo_air;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL,
    role ENUM('admin', 'monitoring_admin') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create sensors table
CREATE TABLE IF NOT EXISTS sensors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create sensor_readings table
CREATE TABLE IF NOT EXISTS sensor_readings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sensor_id INT NOT NULL,
    aqi INT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sensor_id) REFERENCES sensors(id)
);

-- Create alert_thresholds table
CREATE TABLE IF NOT EXISTS alert_thresholds (
    id INT PRIMARY KEY AUTO_INCREMENT,
    level VARCHAR(20) NOT NULL,
    min_value INT NOT NULL,
    max_value INT NOT NULL,
    color VARCHAR(7) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user (username: admin, password: admin)
INSERT INTO users (username, password, role) VALUES 
('admin', 'admin', 'admin');

-- Insert default alert thresholds
INSERT INTO alert_thresholds (level, min_value, max_value, color) VALUES
('Good', 0, 50, '#00e400'),
('Moderate', 51, 100, '#ffff00'),
('Unhealthy', 101, 150, '#ff7e00'),
('Very Unhealthy', 151, 200, '#ff0000'),
('Hazardous', 201, 500, '#8f3f97');

-- Insert sample sensors
INSERT INTO sensors (name, latitude, longitude) VALUES
('Fort', 6.9271, 79.8612),
('Mount Lavinia', 6.8271, 79.8612),
('Battaramulla', 6.8971, 79.9212),
('Kaduwela', 6.9371, 79.9812),
('Moratuwa', 6.7731, 79.8812); 