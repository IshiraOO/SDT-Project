-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2025 at 09:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `colombo_air`
--

-- --------------------------------------------------------

--
-- Table structure for table `alert_thresholds`
--

CREATE TABLE `alert_thresholds` (
  `id` int(11) NOT NULL,
  `level` varchar(20) NOT NULL,
  `min_value` int(11) NOT NULL,
  `max_value` int(11) NOT NULL,
  `color` varchar(7) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alert_thresholds`
--

INSERT INTO `alert_thresholds` (`id`, `level`, `min_value`, `max_value`, `color`, `created_at`) VALUES
(1, 'Good', 0, 50, '#00e400', '2025-03-29 16:36:53'),
(2, 'Moderate', 51, 100, '#ffff00', '2025-03-29 16:36:53'),
(3, 'Unhealthy', 101, 150, '#ff7e00', '2025-03-29 16:36:53'),
(4, 'Very Unhealthy', 151, 200, '#ff0000', '2025-03-29 16:36:53'),
(5, 'Hazardous', 201, 500, '#8f3f97', '2025-03-29 16:36:53');

-- --------------------------------------------------------

--
-- Table structure for table `sensors`
--

CREATE TABLE `sensors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sensors`
--

INSERT INTO `sensors` (`id`, `name`, `latitude`, `longitude`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Fort', 6.92710000, 79.86120000, 'active', '2025-03-29 16:36:53', '2025-03-29 20:04:15'),
(2, 'Mount Lavinia', 6.82710000, 79.86120000, 'active', '2025-03-29 16:36:53', '2025-03-29 16:36:53'),
(4, 'Kaduwela', 6.93710000, 79.98120000, 'active', '2025-03-29 16:36:53', '2025-03-29 16:36:53'),
(5, 'Moratuwa', 6.77310000, 79.88120000, 'active', '2025-03-29 16:36:53', '2025-03-29 16:36:53'),
(6, 'Kottawa', 6.84120000, 79.96540000, 'active', '2025-03-29 16:53:43', '2025-03-29 16:53:43'),
(7, 'Homagama', 6.84330000, 80.00320000, 'active', '2025-03-29 20:04:58', '2025-03-29 20:04:58');

-- --------------------------------------------------------

--
-- Table structure for table `sensor_readings`
--

CREATE TABLE `sensor_readings` (
  `id` int(11) NOT NULL,
  `sensor_id` int(11) NOT NULL,
  `aqi` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sensor_readings`
--

INSERT INTO `sensor_readings` (`id`, `sensor_id`, `aqi`, `timestamp`) VALUES
(1, 1, 215, '2025-03-29 17:08:05'),
(2, 2, 145, '2025-03-29 17:08:05'),
(4, 4, 169, '2025-03-29 17:08:05'),
(5, 5, 116, '2025-03-29 17:08:05'),
(6, 6, 161, '2025-03-29 17:08:05'),
(7, 1, 50, '2025-03-29 17:14:05'),
(8, 2, 238, '2025-03-29 17:14:05'),
(10, 4, 276, '2025-03-29 17:14:05'),
(11, 5, 299, '2025-03-29 17:14:05'),
(12, 6, 243, '2025-03-29 17:14:05'),
(13, 1, 57, '2025-03-29 17:14:08'),
(14, 2, 57, '2025-03-29 17:14:08'),
(16, 4, 79, '2025-03-29 17:14:08'),
(17, 5, 291, '2025-03-29 17:14:08'),
(18, 6, 74, '2025-03-29 17:14:08'),
(19, 1, 91, '2025-03-29 17:14:10'),
(20, 2, 133, '2025-03-29 17:14:10'),
(22, 4, 26, '2025-03-29 17:14:10'),
(23, 5, 193, '2025-03-29 17:14:10'),
(24, 6, 277, '2025-03-29 17:14:10'),
(25, 1, 85, '2025-03-29 17:23:38'),
(26, 2, 182, '2025-03-29 17:23:38'),
(28, 4, 112, '2025-03-29 17:23:38'),
(29, 5, 178, '2025-03-29 17:23:38'),
(30, 6, 123, '2025-03-29 17:23:38'),
(31, 1, 73, '2025-03-29 17:23:39'),
(32, 2, 12, '2025-03-29 17:23:39'),
(34, 4, 184, '2025-03-29 17:23:39'),
(35, 5, 24, '2025-03-29 17:23:39'),
(36, 6, 130, '2025-03-29 17:23:39'),
(37, 1, 152, '2025-03-29 17:23:40'),
(38, 2, 126, '2025-03-29 17:23:40'),
(40, 4, 268, '2025-03-29 17:23:40'),
(41, 5, 124, '2025-03-29 17:23:40'),
(42, 6, 240, '2025-03-29 17:23:40'),
(43, 1, 176, '2025-03-29 17:23:42'),
(44, 2, 79, '2025-03-29 17:23:42'),
(46, 4, 252, '2025-03-29 17:23:42'),
(47, 5, 171, '2025-03-29 17:23:42'),
(48, 6, 144, '2025-03-29 17:23:42'),
(49, 1, 125, '2025-03-29 17:23:47'),
(50, 2, 165, '2025-03-29 17:23:47'),
(52, 4, 169, '2025-03-29 17:23:47'),
(53, 5, 104, '2025-03-29 17:23:47'),
(54, 6, 184, '2025-03-29 17:23:47'),
(55, 1, 296, '2025-03-29 17:25:42'),
(56, 2, 210, '2025-03-29 17:25:42'),
(58, 4, 92, '2025-03-29 17:25:42'),
(59, 5, 139, '2025-03-29 17:25:42'),
(60, 6, 52, '2025-03-29 17:25:42'),
(61, 1, 189, '2025-03-29 17:29:38'),
(62, 2, 204, '2025-03-29 17:29:38'),
(63, 4, 38, '2025-03-29 17:29:38'),
(64, 5, 180, '2025-03-29 17:29:38'),
(65, 6, 241, '2025-03-29 17:29:38'),
(66, 1, 37, '2025-03-29 17:31:23'),
(67, 2, 72, '2025-03-29 17:31:23'),
(68, 4, 117, '2025-03-29 17:31:23'),
(69, 5, 145, '2025-03-29 17:31:23'),
(70, 6, 282, '2025-03-29 17:31:23'),
(71, 1, 236, '2025-03-29 17:54:34'),
(72, 2, 224, '2025-03-29 17:54:34'),
(73, 4, 207, '2025-03-29 17:54:34'),
(74, 5, 168, '2025-03-29 17:54:34'),
(75, 6, 146, '2025-03-29 17:54:34'),
(76, 1, 228, '2025-03-29 17:54:44'),
(77, 2, 263, '2025-03-29 17:54:44'),
(78, 4, 161, '2025-03-29 17:54:44'),
(79, 5, 183, '2025-03-29 17:54:44'),
(80, 6, 180, '2025-03-29 17:54:44'),
(81, 1, 245, '2025-03-29 17:54:45'),
(82, 2, 186, '2025-03-29 17:54:45'),
(83, 4, 1, '2025-03-29 17:54:45'),
(84, 5, 114, '2025-03-29 17:54:45'),
(85, 6, 38, '2025-03-29 17:54:45'),
(86, 1, 153, '2025-03-29 18:09:22'),
(87, 2, 81, '2025-03-29 18:09:22'),
(88, 4, 85, '2025-03-29 18:09:22'),
(89, 5, 294, '2025-03-29 18:09:22'),
(90, 6, 35, '2025-03-29 18:09:22'),
(91, 1, 139, '2025-03-29 18:10:01'),
(92, 2, 69, '2025-03-29 18:10:01'),
(93, 4, 217, '2025-03-29 18:10:01'),
(94, 5, 73, '2025-03-29 18:10:01'),
(95, 6, 22, '2025-03-29 18:10:01'),
(96, 1, 167, '2025-03-29 18:10:02'),
(97, 2, 272, '2025-03-29 18:10:03'),
(98, 4, 77, '2025-03-29 18:10:03'),
(99, 5, 296, '2025-03-29 18:10:03'),
(100, 6, 244, '2025-03-29 18:10:03'),
(101, 1, 219, '2025-03-29 18:24:08'),
(102, 2, 65, '2025-03-29 18:24:08'),
(103, 4, 204, '2025-03-29 18:24:08'),
(104, 5, 101, '2025-03-29 18:24:08'),
(105, 6, 291, '2025-03-29 18:24:08'),
(106, 1, 190, '2025-03-29 18:24:41'),
(107, 2, 46, '2025-03-29 18:24:41'),
(108, 4, 293, '2025-03-29 18:24:41'),
(109, 5, 103, '2025-03-29 18:24:41'),
(110, 6, 1, '2025-03-29 18:24:41'),
(111, 1, 28, '2025-03-29 18:24:52'),
(112, 2, 14, '2025-03-29 18:24:52'),
(113, 4, 47, '2025-03-29 18:24:52'),
(114, 5, 226, '2025-03-29 18:24:52'),
(115, 6, 194, '2025-03-29 18:24:52'),
(116, 1, 257, '2025-03-29 18:25:01'),
(117, 2, 121, '2025-03-29 18:25:01'),
(118, 4, 39, '2025-03-29 18:25:01'),
(119, 5, 40, '2025-03-29 18:25:01'),
(120, 6, 1, '2025-03-29 18:25:01'),
(121, 1, 131, '2025-03-29 19:10:14'),
(122, 2, 16, '2025-03-29 19:10:14'),
(123, 4, 241, '2025-03-29 19:10:14'),
(124, 5, 242, '2025-03-29 19:10:14'),
(125, 6, 143, '2025-03-29 19:10:14'),
(126, 1, 182, '2025-03-29 19:58:55'),
(127, 2, 287, '2025-03-29 19:58:55'),
(128, 4, 194, '2025-03-29 19:58:55'),
(129, 5, 147, '2025-03-29 19:58:55'),
(130, 6, 53, '2025-03-29 19:58:55'),
(131, 1, 282, '2025-03-29 20:05:23'),
(132, 2, 178, '2025-03-29 20:05:23'),
(133, 4, 61, '2025-03-29 20:05:23'),
(134, 5, 5, '2025-03-29 20:05:23'),
(135, 6, 47, '2025-03-29 20:05:23'),
(136, 7, 175, '2025-03-29 20:05:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','monitoring_admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin', 'admin', '2025-03-29 16:36:53'),
(2, 'User', 'User', 'monitoring_admin', '2025-03-29 17:01:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alert_thresholds`
--
ALTER TABLE `alert_thresholds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensors`
--
ALTER TABLE `sensors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sensor_readings`
--
ALTER TABLE `sensor_readings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sensor_id` (`sensor_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alert_thresholds`
--
ALTER TABLE `alert_thresholds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sensors`
--
ALTER TABLE `sensors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sensor_readings`
--
ALTER TABLE `sensor_readings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sensor_readings`
--
ALTER TABLE `sensor_readings`
  ADD CONSTRAINT `sensor_readings_ibfk_1` FOREIGN KEY (`sensor_id`) REFERENCES `sensors` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
