<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colombo Air Quality Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #1a5f7a;
            --secondary-color: #2ecc71;
            --success-color: #27ae60;
            --warning-color: #f1c40f;
            --danger-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #1a5f7a;
            --text-primary: #2c3e50;
            --text-secondary: #7f8c8d;
            --header-gradient: linear-gradient(135deg, #1a5f7a 0%, #2ecc71 100%);
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--light-bg);
            color: var(--text-primary);
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(125deg, rgba(26, 95, 122, 0.05) 0%, rgba(46, 204, 113, 0.05) 100%);
            animation: gradientAnimation 15s ease infinite;
            z-index: -1;
        }

        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                45deg,
                rgba(255, 255, 255, 0.05) 0px,
                rgba(255, 255, 255, 0.05) 10px,
                transparent 10px,
                transparent 20px
            );
            animation: patternAnimation 20s linear infinite;
            z-index: -1;
        }

        @keyframes patternAnimation {
            from {
                transform: translateX(-20px) translateY(20px);
            }
            to {
                transform: translateX(20px) translateY(-20px);
            }
        }

        header {
            background: var(--header-gradient);
            padding: 1.5rem 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }

        header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, rgba(255,255,255,0.1) 25%, transparent 25%),
                        linear-gradient(-45deg, rgba(255,255,255,0.1) 25%, transparent 25%),
                        linear-gradient(45deg, transparent 75%, rgba(255,255,255,0.1) 75%),
                        linear-gradient(-45deg, transparent 75%, rgba(255,255,255,0.1) 75%);
            background-size: 20px 20px;
            opacity: 0.1;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        .logo {
            color: white;
            font-size: 1.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        nav ul {
            display: flex;
            gap: 2rem;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 0.7rem 1.2rem;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.2);
        }

        nav a:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        nav a i {
            margin-right: 0.5rem;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0 0 1.5rem 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .top-sensors {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 1.5rem;
            margin-bottom: 2rem;
            padding: 0 1rem;
        }

        .sensor-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .sensor-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.12);
        }

        .sensor-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--header-gradient);
        }

        .sensor-name {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .sensor-aqi {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--secondary-color);
            margin: 0.5rem 0;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }

        .sensor-aqi-label {
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sensor-readings {
            font-size: 0.85rem;
            color: var(--text-secondary);
            padding: 0.4rem 0.8rem;
            background: rgba(0,0,0,0.03);
            border-radius: 15px;
            display: inline-block;
        }

        @media (max-width: 1200px) {
            .top-sensors {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 768px) {
            .top-sensors {
                grid-template-columns: repeat(2, 1fr);
                padding: 0 0.5rem;
            }
            .section-title {
                margin-left: 0.5rem;
                font-size: 1.3rem;
            }
        }

        @media (max-width: 480px) {
            .top-sensors {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            header {
                padding: 1rem;
            }

            nav {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .logo {
                font-size: 1.5rem;
            }

            nav ul {
                flex-direction: column;
                gap: 0.8rem;
            }

            nav a {
                display: block;
                width: 100%;
                max-width: 200px;
                margin: 0 auto;
            }
        }

        .dashboard-container {
            max-width: 100%;
            margin: 0;
            padding: 2rem 1rem;
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .map-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
            position: relative;
            width: 100%;
            margin: 0;
            padding: 0;
        }

        #map {
            height: 500px;
            width: 100%;
            border-radius: 10px;
            margin: 0;
            padding: 0;
            position: relative;
            z-index: 1;
        }

        .legend {
            position: absolute;
            bottom: 20px;
            right: 20px;
            background: white;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            min-width: 200px;
        }

        .legend h3 {
            margin: 0 0 1rem 0;
            color: var(--text-primary);
            font-size: 1rem;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .color-box {
            width: 20px;
            height: 20px;
            border-radius: 4px;
        }

        .good { background: var(--success-color); }
        .moderate { background: var(--warning-color); }
        .unhealthy { background: #f39c12; }
        .very-unhealthy { background: var(--danger-color); }
        .hazardous { background: #8e44ad; }

        .chart-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            width: 100%;
        }

        .chart-container h2 {
            margin: 0 0 1.5rem 0;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.5rem;
        }

        .chart-controls {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        select {
            padding: 0.7rem 1.2rem;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: white;
            color: var(--text-primary);
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 200px;
        }

        select:hover {
            border-color: var(--secondary-color);
            transform: translateY(-1px);
        }

        select:focus {
            outline: none;
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 2px rgba(46, 204, 113, 0.2);
        }

        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1rem;
                gap: 1rem;
            }

            #map {
                height: 400px;
            }

            .legend {
                min-width: 180px;
                right: 10px;
                bottom: 10px;
            }
        }

        .leaflet-popup-content-wrapper {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            overflow: hidden;
            padding: 0;
            min-width: 280px;
        }

        .leaflet-popup-content {
            margin: 0;
            padding: 0;
        }

        .leaflet-popup-tip {
            background: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .popup-content {
            padding: 0;
        }

        .popup-header {
            background: var(--header-gradient);
            color: white;
            padding: 1rem;
            position: relative;
            text-align: center;
        }

        .popup-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }

        .popup-aqi {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0.5rem 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .popup-status {
            display: inline-block;
            padding: 0.3rem 1rem;
            border-radius: 15px;
            background: rgba(255,255,255,0.2);
            font-size: 0.9rem;
            margin-top: 0.5rem;
        }

        .popup-body {
            padding: 1rem;
        }

        .popup-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .popup-detail:last-child {
            border-bottom: none;
        }

        .popup-detail i {
            width: 20px;
            color: var(--primary-color);
        }

        .popup-detail-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
            flex: 1;
        }

        .popup-detail-value {
            font-weight: 600;
            color: var(--text-primary);
        }

        .popup-footer {
            background: rgba(0,0,0,0.02);
            padding: 0.8rem;
            text-align: center;
            font-size: 0.85rem;
            color: var(--text-secondary);
            border-top: 1px solid rgba(0,0,0,0.05);
        }

        .status-good { background: var(--success-color); }
        .status-moderate { background: var(--warning-color); }
        .status-unhealthy { background: #f39c12; }
        .status-very-unhealthy { background: var(--danger-color); }
        .status-hazardous { background: #8e44ad; }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">Colombo Air Quality</div>
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="admin/login.php"><i class="fas fa-lock"></i> Admin</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="dashboard-container">
            <h2 class="section-title"><i class="fas fa-chart-bar"></i> Top 5 Sensors</h2>
            <div class="top-sensors">
                <div class="sensor-card">
                    <div class="sensor-name">Moratuwa</div>
                    <div class="sensor-aqi-label">AQI</div>
                    <div class="sensor-aqi">165</div>
                    <div class="sensor-readings">23 readings</div>
                </div>
                <div class="sensor-card">
                    <div class="sensor-name">Fort</div>
                    <div class="sensor-aqi-label">AQI</div>
                    <div class="sensor-aqi">154</div>
                    <div class="sensor-readings">25 readings</div>
                </div>
                <div class="sensor-card">
                    <div class="sensor-name">Kottawa</div>
                    <div class="sensor-aqi-label">AQI</div>
                    <div class="sensor-aqi">150</div>
                    <div class="sensor-readings">22 readings</div>
                </div>
                <div class="sensor-card">
                    <div class="sensor-name">Kaduwela</div>
                    <div class="sensor-aqi-label">AQI</div>
                    <div class="sensor-aqi">146</div>
                    <div class="sensor-readings">23 readings</div>
                </div>
                <div class="sensor-card">
                    <div class="sensor-name">Mount Lavinia</div>
                    <div class="sensor-aqi-label">AQI</div>
                    <div class="sensor-aqi">130</div>
                    <div class="sensor-readings">23 readings</div>
                </div>
            </div>

            <div class="map-container">
                <div id="map"></div>
                <div class="legend">
                    <h3><i class="fas fa-info-circle"></i> AQI Levels</h3>
                    <div class="legend-item">
                        <span class="color-box good"></span>
                        <span>Good (0-50)</span>
                    </div>
                    <div class="legend-item">
                        <span class="color-box moderate"></span>
                        <span>Moderate (51-100)</span>
                    </div>
                    <div class="legend-item">
                        <span class="color-box unhealthy"></span>
                        <span>Unhealthy (101-150)</span>
                    </div>
                    <div class="legend-item">
                        <span class="color-box very-unhealthy"></span>
                        <span>Very Unhealthy (151-200)</span>
                    </div>
                    <div class="legend-item">
                        <span class="color-box hazardous"></span>
                        <span>Hazardous (201+)</span>
                    </div>
                </div>
            </div>
            <div class="chart-container">
                <h2><i class="fas fa-chart-line"></i> Historical Data</h2>
                <div class="chart-controls">
                    <select id="timeRange">
                        <option value="24">Last 24 Hours</option>
                        <option value="168">Last Week</option>
                        <option value="720">Last Month</option>
                    </select>
                    <select id="sensorSelect">
                        <option value="">Select a Sensor</option>
                    </select>
                </div>
                <canvas id="aqiChart"></canvas>
            </div>
        </div>
    </main>

    <script src="assets/js/dashboard.js"></script>

    <script>
        function getAQIStatus(aqi) {
            if (aqi <= 50) return ['Good', 'status-good'];
            if (aqi <= 100) return ['Moderate', 'status-moderate'];
            if (aqi <= 150) return ['Unhealthy', 'status-unhealthy'];
            if (aqi <= 200) return ['Very Unhealthy', 'status-very-unhealthy'];
            return ['Hazardous', 'status-hazardous'];
        }

        function createPopupContent(sensor) {
            const [status, statusClass] = getAQIStatus(sensor.aqi);
            const lastUpdate = new Date(sensor.lastUpdate).toLocaleString();
            
            return `
                <div class="popup-content">
                    <div class="popup-header ${statusClass}">
                        <div class="popup-title">${sensor.name}</div>
                        <div class="popup-aqi">${sensor.aqi}</div>
                        <div class="popup-status">${status}</div>
                    </div>
                    <div class="popup-body">
                        <div class="popup-detail">
                            <i class="fas fa-map-marker-alt"></i>
                            <span class="popup-detail-label">Location</span>
                            <span class="popup-detail-value">${sensor.location}</span>
                        </div>
                        <div class="popup-detail">
                            <i class="fas fa-temperature-high"></i>
                            <span class="popup-detail-label">Temperature</span>
                            <span class="popup-detail-value">${sensor.temperature}°C</span>
                        </div>
                        <div class="popup-detail">
                            <i class="fas fa-tint"></i>
                            <span class="popup-detail-label">Humidity</span>
                            <span class="popup-detail-value">${sensor.humidity}%</span>
                        </div>
                        <div class="popup-detail">
                            <i class="fas fa-wind"></i>
                            <span class="popup-detail-label">Wind Speed</span>
                            <span class="popup-detail-value">${sensor.windSpeed} km/h</span>
                        </div>
                    </div>
                    <div class="popup-footer">
                        <i class="fas fa-clock"></i> Last Updated: ${lastUpdate}
                    </div>
                </div>
            `;
        }
    </script>
</body>
</html> 