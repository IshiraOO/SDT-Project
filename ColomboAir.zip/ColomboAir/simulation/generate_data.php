<?php
require_once '../config/database.php';

// Function to generate random AQI with some variation
function generateAQI($baseline = 50) {
    // Generate random variation between -20 and +20
    $variation = rand(-20, 20);
    $aqi = $baseline + $variation;
    
    // Ensure AQI stays within valid range (0-500)
    return max(0, min(500, $aqi));
}

// Main simulation loop
while (true) {
    // Check if simulation should be running
    if (!file_exists(__DIR__ . '/running.flag')) {
        sleep(5);
        continue;
    }

    try {
        // Get all active sensors
        $stmt = $pdo->query("SELECT id FROM sensors WHERE status = 'active'");
        $sensors = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Generate readings for each sensor
        $stmt = $pdo->prepare("
            INSERT INTO sensor_readings (sensor_id, aqi)
            VALUES (?, ?)
        ");

        foreach ($sensors as $sensor_id) {
            // Generate random AQI between 0 and 300
            $aqi = generateAQI();
            $stmt->execute([$sensor_id, $aqi]);
        }

        // Log the generation
        error_log("Generated readings for " . count($sensors) . " sensors at " . date('Y-m-d H:i:s'));

        // Wait for 5 minutes before next generation
        sleep(300);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        sleep(60); // Wait a minute before retrying
    }
}
?> 