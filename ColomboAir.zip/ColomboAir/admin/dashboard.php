<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get sensor statistics
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_sensors,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_sensors,
            (SELECT COUNT(*) FROM sensor_readings) as total_readings,
            (SELECT AVG(aqi) FROM sensor_readings WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as avg_aqi_24h
        FROM sensors
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get recent readings with sensor names
    $stmt = $pdo->query("
        SELECT sr.*, s.name, s.latitude, s.longitude
        FROM sensor_readings sr
        JOIN sensors s ON sr.sensor_id = s.id
        ORDER BY sr.timestamp DESC
        LIMIT 10
    ");
    $recent_readings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get AQI distribution
    $stmt = $pdo->query("
        SELECT 
            CASE 
                WHEN aqi <= 50 THEN 'Good'
                WHEN aqi <= 100 THEN 'Moderate'
                WHEN aqi <= 150 THEN 'Unhealthy'
                WHEN aqi <= 200 THEN 'Very Unhealthy'
                ELSE 'Hazardous'
            END as category,
            COUNT(*) as count
        FROM sensor_readings
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        GROUP BY category
        ORDER BY 
            CASE category
                WHEN 'Good' THEN 1
                WHEN 'Moderate' THEN 2
                WHEN 'Unhealthy' THEN 3
                WHEN 'Very Unhealthy' THEN 4
                ELSE 5
            END
    ");
    $aqi_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get hourly AQI data for the last 24 hours
    $stmt = $pdo->query("
        SELECT 
            DATE_FORMAT(timestamp, '%Y-%m-%d %H:00:00') as hour,
            AVG(aqi) as avg_aqi
        FROM sensor_readings
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        GROUP BY hour
        ORDER BY hour
    ");
    $hourly_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get top 5 sensors by average AQI
    $stmt = $pdo->query("
        SELECT 
            s.name,
            AVG(sr.aqi) as avg_aqi,
            COUNT(sr.id) as reading_count
        FROM sensors s
        JOIN sensor_readings sr ON s.id = sr.sensor_id
        WHERE sr.timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        GROUP BY s.id, s.name
        ORDER BY avg_aqi DESC
        LIMIT 5
    ");
    $top_sensors = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Colombo Air Quality</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: calc(100vh - 60px);
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            padding: 1rem;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar li {
            margin: 0.5rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 0.5rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background: #34495e;
        }
        .sidebar a i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        .main-content {
            padding: 2rem;
            background: #f8f9fa;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card h3 {
            margin: 0;
            color: #2c3e50;
            font-size: 1.1rem;
        }
        .stat-card .value {
            font-size: 2rem;
            font-weight: bold;
            margin: 0.5rem 0;
        }
        .stat-card .icon {
            font-size: 2rem;
            color: #3498db;
            margin-bottom: 1rem;
        }
        .recent-readings {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .recent-readings h3 {
            margin-top: 0;
            color: #2c3e50;
        }
        .readings-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .readings-table th,
        .readings-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .readings-table th {
            background: #f8f9fa;
            color: #2c3e50;
        }
        .aqi-distribution {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .aqi-distribution h3 {
            margin-top: 0;
            color: #2c3e50;
        }
        .distribution-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        .distribution-item {
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
        }
        .distribution-item.good { background: #00e400; color: white; }
        .distribution-item.moderate { background: #ffff00; color: black; }
        .distribution-item.unhealthy { background: #ff7e00; color: white; }
        .distribution-item.very-unhealthy { background: #ff0000; color: white; }
        .distribution-item.hazardous { background: #8f3f97; color: white; }
        .distribution-item .count {
            font-size: 1.5rem;
            font-weight: bold;
            margin: 0.5rem 0;
        }
        .welcome-section {
            margin-bottom: 2rem;
        }
        .welcome-section h1 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        .welcome-section p {
            color: #7f8c8d;
        }
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .chart-card h3 {
            margin-top: 0;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 1rem;
        }
        .top-sensors {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .top-sensors h3 {
            margin-top: 0;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .sensor-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        .sensor-item {
            padding: 1rem;
            border-radius: 8px;
            background: #f8f9fa;
        }
        .sensor-item .name {
            font-weight: bold;
            color: #2c3e50;
        }
        .sensor-item .aqi {
            font-size: 1.2rem;
            color: #3498db;
            margin: 0.5rem 0;
        }
        .sensor-item .readings {
            color: #7f8c8d;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">Colombo Air Quality</div>
            <ul>
                <li><a href="../index.php">Public Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="admin-container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="sensors.php"><i class="fas fa-microchip"></i> Manage Sensors</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                <li><a href="alerts.php"><i class="fas fa-bell"></i> Alert Settings</a></li>
                <li><a href="simulation.php"><i class="fas fa-play"></i> Data Simulation</a></li>
            </ul>
        </div>

        <div class="main-content">
            <div class="welcome-section">
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
                <p>Here's an overview of your air quality monitoring system.</p>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-microchip"></i></div>
                    <h3>Total Sensors</h3>
                    <div class="value"><?php echo $stats['total_sensors']; ?></div>
                    <div class="subtitle">Active: <?php echo $stats['active_sensors']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-database"></i></div>
                    <h3>Total Readings</h3>
                    <div class="value"><?php echo number_format($stats['total_readings']); ?></div>
                    <div class="subtitle">Last 24 hours</div>
                </div>
                <div class="stat-card">
                    <div class="icon"><i class="fas fa-chart-line"></i></div>
                    <h3>Average AQI</h3>
                    <div class="value"><?php echo round($stats['avg_aqi_24h']); ?></div>
                    <div class="subtitle">Last 24 hours</div>
                </div>
            </div>

            <div class="charts-grid">
                <div class="chart-card">
                    <h3><i class="fas fa-chart-line"></i> AQI Trend (24h)</h3>
                    <div class="chart-container">
                        <canvas id="aqiTrendChart"></canvas>
                    </div>
                </div>
                <div class="chart-card">
                    <h3><i class="fas fa-chart-bar"></i> Top Sensors by AQI</h3>
                    <div class="chart-container">
                        <canvas id="topSensorsChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="top-sensors">
                <h3><i class="fas fa-list-ol"></i> Top 5 Sensors</h3>
                <div class="sensor-list">
                    <?php foreach ($top_sensors as $sensor): ?>
                        <div class="sensor-item">
                            <div class="name"><?php echo htmlspecialchars($sensor['name']); ?></div>
                            <div class="aqi">AQI: <?php echo round($sensor['avg_aqi']); ?></div>
                            <div class="readings"><?php echo $sensor['reading_count']; ?> readings</div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="recent-readings">
                <h3><i class="fas fa-clock"></i> Recent Readings</h3>
                <table class="readings-table">
                    <thead>
                        <tr>
                            <th>Sensor</th>
                            <th>AQI</th>
                            <th>Location</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_readings as $reading): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($reading['name']); ?></td>
                                <td><?php echo $reading['aqi']; ?></td>
                                <td><?php echo $reading['latitude']; ?>, <?php echo $reading['longitude']; ?></td>
                                <td><?php echo date('Y-m-d H:i:s', strtotime($reading['timestamp'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="aqi-distribution">
                <h3><i class="fas fa-chart-pie"></i> AQI Distribution (24h)</h3>
                <div class="distribution-grid">
                    <?php foreach ($aqi_distribution as $dist): ?>
                        <div class="distribution-item <?php echo strtolower($dist['category']); ?>">
                            <div class="category"><?php echo $dist['category']; ?></div>
                            <div class="count"><?php echo $dist['count']; ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // AQI Trend Chart
        const aqiTrendCtx = document.getElementById('aqiTrendChart').getContext('2d');
        new Chart(aqiTrendCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($hourly_data, 'hour')); ?>,
                datasets: [{
                    label: 'Average AQI',
                    data: <?php echo json_encode(array_column($hourly_data, 'avg_aqi')); ?>,
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Top Sensors Chart
        const topSensorsCtx = document.getElementById('topSensorsChart').getContext('2d');
        new Chart(topSensorsCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($top_sensors, 'name')); ?>,
                datasets: [{
                    label: 'Average AQI',
                    data: <?php echo json_encode(array_column($top_sensors, 'avg_aqi')); ?>,
                    backgroundColor: '#3498db',
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    </script>
</body>
</html> 