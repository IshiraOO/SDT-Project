<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'add':
                    $stmt = $pdo->prepare("
                        INSERT INTO users (username, password, role)
                        VALUES (?, ?, ?)
                    ");
                    $stmt->execute([
                        $_POST['username'],
                        $_POST['password'], // Store plain text password as requested
                        $_POST['role']
                    ]);
                    break;

                case 'update':
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET username = ?, password = ?, role = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $_POST['username'],
                        $_POST['password'], // Store plain text password as requested
                        $_POST['role'],
                        $_POST['user_id']
                    ]);
                    break;

                case 'delete':
                    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                    $stmt->execute([$_POST['user_id']]);
                    break;
            }
            header('Location: users.php');
            exit;
        }
    } catch(PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Get all users
try {
    $stmt = $pdo->query("SELECT * FROM users ORDER BY username");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Colombo Air Quality</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: calc(100vh - 60px);
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            padding: 1rem;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar li {
            margin: 0.5rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 0.5rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background: #34495e;
        }
        .sidebar a i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        .main-content {
            padding: 2rem;
            background: #f8f9fa;
        }
        .page-header {
            margin-bottom: 2rem;
        }
        .page-header h1 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        .page-header p {
            color: #7f8c8d;
        }
        .user-form {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .user-form h3 {
            color: #2c3e50;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2c3e50;
            font-weight: 500;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
            transform: translateY(-1px);
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        .btn-danger:hover {
            background: #c0392b;
            transform: translateY(-1px);
        }
        .users-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .users-table th,
        .users-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .users-table th {
            background: #f8f9fa;
            color: #2c3e50;
            font-weight: 600;
        }
        .users-table tr:last-child td {
            border-bottom: none;
        }
        .users-table tr:hover td {
            background: #f8f9fa;
        }
        .role-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        .role-admin {
            background: #e3f2fd;
            color: #1976d2;
        }
        .role-provider {
            background: #e8f5e9;
            color: #2e7d32;
        }
        .role-public {
            background: #fff3e0;
            color: #f57c00;
        }
        .error {
            background: #ffebee;
            color: #c62828;
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .actions {
            display: flex;
            gap: 0.5rem;
        }
        .edit-btn {
            background: #f8f9fa;
            color: #2c3e50;
            padding: 0.5rem;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .edit-btn:hover {
            background: #e9ecef;
            color: #3498db;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">Colombo Air Quality</div>
            <ul>
                <li><a href="../index.php">Public Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="admin-container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="sensors.php"><i class="fas fa-microchip"></i> Manage Sensors</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                <li><a href="alerts.php"><i class="fas fa-bell"></i> Alert Settings</a></li>
                <li><a href="simulation.php"><i class="fas fa-play"></i> Data Simulation</a></li>
            </ul>
        </div>

        <div class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-users"></i> Manage Users</h1>
                <p>Add, edit, or remove user accounts from the system.</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="user-form">
                <h3><i class="fas fa-user-plus"></i> Add New User</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required placeholder="Enter username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="text" id="password" name="password" required placeholder="Enter password">
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" required>
                            <option value="admin">Admin</option>
                            <option value="provider">Data Provider</option>
                            <option value="public">Public User</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add User
                    </button>
                </form>
            </div>

            <h3><i class="fas fa-list"></i> Existing Users</h3>
            <table class="users-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['password']); ?></td>
                            <td>
                                <span class="role-badge role-<?php echo strtolower($user['role']); ?>">
                                    <i class="fas fa-user-<?php echo $user['role'] === 'admin' ? 'shield' : ($user['role'] === 'provider' ? 'database' : 'user'); ?>"></i>
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td class="actions">
                                <button class="edit-btn" onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" class="btn btn-danger">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function editUser(user) {
            // Populate the form with user data
            document.getElementById('username').value = user.username;
            document.getElementById('password').value = user.password;
            document.getElementById('role').value = user.role;
            
            // Change form action to update
            const form = document.querySelector('.user-form form');
            form.querySelector('input[name="action"]').value = 'update';
            form.innerHTML += `<input type="hidden" name="user_id" value="${user.id}">`;
            
            // Scroll to the form
            document.querySelector('.user-form').scrollIntoView({ behavior: 'smooth' });
        }
    </script>
</body>
</html> 