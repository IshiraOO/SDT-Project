<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'start':
                    // Start simulation by creating a flag file
                    file_put_contents('../simulation/running.flag', '1');
                    break;

                case 'stop':
                    // Stop simulation by removing the flag file
                    if (file_exists('../simulation/running.flag')) {
                        unlink('../simulation/running.flag');
                    }
                    break;

                case 'generate':
                    // Generate one-time data for all active sensors
                    $stmt = $pdo->query("SELECT id FROM sensors WHERE status = 'active'");
                    $sensors = $stmt->fetchAll(PDO::FETCH_COLUMN);

                    $stmt = $pdo->prepare("
                        INSERT INTO sensor_readings (sensor_id, aqi)
                        VALUES (?, ?)
                    ");

                    foreach ($sensors as $sensor_id) {
                        // Generate random AQI between 0 and 300
                        $aqi = rand(0, 300);
                        $stmt->execute([$sensor_id, $aqi]);
                    }
                    break;
            }
            header('Location: simulation.php');
            exit;
        }
    } catch(PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Check if simulation is running
$is_running = file_exists('../simulation/running.flag');

// Get simulation statistics
try {
    $stmt = $pdo->query("
        SELECT 
            COUNT(*) as total_readings,
            MIN(timestamp) as first_reading,
            MAX(timestamp) as last_reading,
            AVG(aqi) as avg_aqi
        FROM sensor_readings
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get readings per hour for the last 24 hours
    $stmt = $pdo->query("
        SELECT 
            DATE_FORMAT(timestamp, '%Y-%m-%d %H:00:00') as hour,
            COUNT(*) as reading_count,
            AVG(aqi) as avg_aqi
        FROM sensor_readings
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        GROUP BY hour
        ORDER BY hour
    ");
    $hourly_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Simulation - Colombo Air Quality</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: calc(100vh - 60px);
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            padding: 1rem;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar li {
            margin: 0.5rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 0.5rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background: #34495e;
        }
        .sidebar a i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        .main-content {
            padding: 2rem;
            background: #f8f9fa;
        }
        .page-header {
            margin-bottom: 2rem;
        }
        .page-header h1 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        .page-header p {
            color: #7f8c8d;
        }
        .simulation-controls {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .control-card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .control-card:hover {
            transform: translateY(-5px);
        }
        .control-card h3 {
            color: #2c3e50;
            margin-top: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .control-card p {
            color: #7f8c8d;
            margin-bottom: 1.5rem;
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
        }
        .btn-primary {
            background: #3498db;
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
            transform: translateY(-1px);
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        .btn-danger:hover {
            background: #c0392b;
            transform: translateY(-1px);
        }
        .btn-success {
            background: #2ecc71;
            color: white;
        }
        .btn-success:hover {
            background: #27ae60;
            transform: translateY(-1px);
        }
        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
            margin-bottom: 1rem;
        }
        .status-running {
            background: #e8f5e9;
            color: #2e7d32;
        }
        .status-stopped {
            background: #ffebee;
            color: #c62828;
        }
        .stats-card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .stats-card h3 {
            color: #2c3e50;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 1.5rem;
        }
        .stat-item {
            text-align: center;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 8px;
            transition: transform 0.3s;
        }
        .stat-item:hover {
            transform: translateY(-5px);
        }
        .stat-item h4 {
            margin: 0;
            color: #2c3e50;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .stat-item .value {
            font-size: 2rem;
            font-weight: bold;
            color: #3498db;
            margin: 0.5rem 0;
        }
        .stat-item .subtitle {
            color: #7f8c8d;
            font-size: 0.875rem;
        }
        .chart-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 2rem;
        }
        .chart-container h3 {
            color: #2c3e50;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .error {
            background: #ffebee;
            color: #c62828;
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">Colombo Air Quality</div>
            <ul>
                <li><a href="../index.php">Public Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="admin-container">
        <div class="sidebar">
            <h2>Admin Panel</h2>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="sensors.php"><i class="fas fa-microchip"></i> Manage Sensors</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Manage Users</a></li>
                <li><a href="alerts.php"><i class="fas fa-bell"></i> Alert Settings</a></li>
                <li><a href="simulation.php"><i class="fas fa-play"></i> Data Simulation</a></li>
            </ul>
        </div>

        <div class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-play"></i> Data Simulation</h1>
                <p>Control and monitor the air quality data simulation process.</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="simulation-controls">
                <div class="control-card">
                    <h3><i class="fas fa-power-off"></i> Simulation Status</h3>
                    <div class="status-indicator <?php echo $is_running ? 'status-running' : 'status-stopped'; ?>">
                        <i class="fas fa-circle"></i>
                        <?php echo $is_running ? 'Running' : 'Stopped'; ?>
                    </div>
                    <?php if ($is_running): ?>
                        <form method="POST">
                            <input type="hidden" name="action" value="stop">
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-stop"></i> Stop Simulation
                            </button>
                        </form>
                    <?php else: ?>
                        <form method="POST">
                            <input type="hidden" name="action" value="start">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-play"></i> Start Simulation
                            </button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="control-card">
                    <h3><i class="fas fa-database"></i> Generate Data</h3>
                    <p>Generate one-time readings for all active sensors</p>
                    <form method="POST">
                        <input type="hidden" name="action" value="generate">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-plus"></i> Generate Readings
                        </button>
                    </form>
                </div>
            </div>

            <div class="stats-card">
                <h3><i class="fas fa-chart-bar"></i> Simulation Statistics</h3>
                <div class="stats-grid">
                    <div class="stat-item">
                        <h4>Total Readings</h4>
                        <div class="value"><?php echo number_format($stats['total_readings']); ?></div>
                        <div class="subtitle">Last 24 hours</div>
                    </div>
                    <div class="stat-item">
                        <h4>Average AQI</h4>
                        <div class="value"><?php echo round($stats['avg_aqi']); ?></div>
                        <div class="subtitle">Last 24 hours</div>
                    </div>
                    <div class="stat-item">
                        <h4>First Reading</h4>
                        <div class="value"><?php echo $stats['first_reading'] ? date('H:i', strtotime($stats['first_reading'])) : 'N/A'; ?></div>
                        <div class="subtitle">24h ago</div>
                    </div>
                    <div class="stat-item">
                        <h4>Last Reading</h4>
                        <div class="value"><?php echo $stats['last_reading'] ? date('H:i', strtotime($stats['last_reading'])) : 'N/A'; ?></div>
                        <div class="subtitle">Most recent</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 