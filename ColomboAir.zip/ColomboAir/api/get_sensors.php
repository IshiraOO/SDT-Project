<?php
header('Content-Type: application/json');
require_once '../config/database.php';

try {
    $stmt = $pdo->query("
        SELECT s.*, 
               (SELECT aqi FROM sensor_readings 
                WHERE sensor_id = s.id 
                ORDER BY timestamp DESC 
                LIMIT 1) as aqi,
               (SELECT timestamp FROM sensor_readings 
                WHERE sensor_id = s.id 
                ORDER BY timestamp DESC 
                LIMIT 1) as last_updated
        FROM sensors s
        WHERE s.status = 'active'
    ");
    
    $sensors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($sensors);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?> 