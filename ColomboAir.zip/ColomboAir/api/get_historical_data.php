<?php
header('Content-Type: application/json');
require_once '../config/database.php';

try {
    $sensor_id = isset($_GET['sensor_id']) ? (int)$_GET['sensor_id'] : 0;
    $hours = isset($_GET['hours']) ? (int)$_GET['hours'] : 24;

    if ($sensor_id <= 0) {
        throw new Exception('Invalid sensor ID');
    }

    $stmt = $pdo->prepare("
        SELECT aqi, timestamp
        FROM sensor_readings
        WHERE sensor_id = ?
        AND timestamp >= DATE_SUB(NOW(), INTERVAL ? HOUR)
        ORDER BY timestamp ASC
    ");
    
    $stmt->execute([$sensor_id, $hours]);
    $readings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($readings);
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 